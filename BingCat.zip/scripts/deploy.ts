import { ethers } from "hardhat";

async function deployContract(contractName: any, ...args: any[]) {

    const Contract = await ethers.getContractFactory(contractName);
    const contract = await Contract.deploy(...args);
    await contract.deployed();
    console.log(`${contractName} deployed to:`  , contract.address);
    return contract;
}
async function deployBlastContract() {
    const router = '0xC532a74256D3Db42D0Bf7a0400fEFDbad7694008'; // replace
    const charityHolder = '0x87fa4Fbda18724600C79668F1585b088cd952D7E'; // replace
    const claimableYieldGoverner = '0x87fa4Fbda18724600C79668F1585b088cd952D7E';
    const iblast = '0x4300000000000000000000000000000000000002'; // replace
    const taxFee = 2; // replace
    const liquidityFee = 2; // replace
    const burnFee = 2; // replace
    const token = await deployContract("BingCat", "Bing Cat", "$BING", ethers.utils.parseEther("1000000000.0"), router, charityHolder, taxFee, liquidityFee, burnFee, iblast, claimableYieldGoverner);
    // console.log("token done");
    try {
    // VERIFICATION
        await run("verify:verify", {
            address: token.address,
            constructorArguments: [
                "Mir Token2", "MIR2", ethers.utils.parseEther("1000000000.0"), router, charity, taxFee, liquidityFee, burnFee
            ],
        });
    } catch (error) {
        console.log(error);
    }
}
deployBlastContract()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
