import "@nomiclabs/hardhat-ethers";
import "@nomicfoundation/hardhat-verify";

import { HardhatUserConfig } from "hardhat/config";

const INFURA_KEY = "f677366a081043149288a2f53f7e502e";
const config: HardhatUserConfig = {
  defaultNetwork: "blast-sepolia",
  networks: {
    "sepolia": {
      url: `https://sepolia.infura.io/v3/${INFURA_KEY}`,
      gas: 2100000,
      gasPrice: 8000000000,
      chainId: 11155111,
      accounts: [""] //BE VERY CAREFUL, DO NOT PUSH THIS TO GITHUB
    },
    "mode": {
      url: "https://sepolia.mode.network/",
      chainId: 919,
      accounts: [""] //BE VERY CAREFUL, DO NOT PUSH THIS TO GITHUB
    },
    "blast-mainnet": {
      url: "coming end of February",
      gasPrice: 1000000000,
      accounts: [""] //BE VERY CAREFUL, DO NOT PUSH THIS TO GITHUB
    },
    // for Sepolia testnet
    "blast-sepolia": {
      url: "https://sepolia.blast.io",
      chainId: 168587773,
      gas: 2100000,
      gasPrice: 8000000000,
      accounts: [""] //BE VERY CAREFUL, DO NOT PUSH THIS TO GITHUB
    },
    // for local dev environment
    "blast-local": {
      url: "http://localhost:8545",
      gasPrice: 1000000000,
      accounts: [""] //BE VERY CAREFUL, DO NOT PUSH THIS TO GITHUB
    },
  },
  etherscan: {
    apiKey: {
      "mode": "MODE-NETWORK-TESTNET",
      "blast-sepolia": "MODE-NETWORK-TESTNET",
      "sepolia": "3EQ6Y34K1XCMEF2WW2VXNGBZDV6Q7ICXSU"
    },
    customChains: [
      {
        network: "mode",
        chainId: 919,
        urls: {
          apiURL: "https://sepolia.explorer.mode.network/api",
          browserURL: "https://sepolia.explorer.mode.network",
        },
      },
      {
        network: "blast-sepolia",
        chainId: 168587773,
        urls: {
          apiURL: "https://api.routescan.io/v2/network/testnet/evm/168587773/etherscan",
          browserURL: "https://testnet.blastscan.io"
        }
      }
    ],
  },
  sourcify: {
    enabled: false,
  },
  solidity: {
    compilers: [
      {
        version: "0.8.0",
        settings: {
          optimizer: {
            enabled: true,
            runs: 99999,
          },
        },
      },
        {
            version: "0.8.20",
            settings: {
            optimizer: {
                enabled: true,
                runs: 99999,
            },
            },
        },
      {
        version: "0.8.4",
        settings: {
          optimizer: {
            enabled: true,
            runs: 99999,
          },
        },
      },
      {
        version: "0.6.6",
        settings: {
          optimizer: {
            enabled: true,
            runs: 99999,
          },
        },
      },
      {
        version: "0.5.16",
        settings: {
          optimizer: {
            enabled: true,
            runs: 99999,
          },
        },
      },
      {
        version: "0.4.18",
        settings: {
          optimizer: {
            enabled: true,
            runs: 99999,
          },
        },
      },
    ],
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
  }
};

export default config;
